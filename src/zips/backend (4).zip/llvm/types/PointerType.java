package llvm.types;

public class PointerType extends ValueType {
    private final ValueType pointedType;    // 指针指向的类型

    public PointerType(ValueType pointedType) {
        this.pointedType = pointedType;
    }

//    public PointerType(ValueType pointedType) {
//        this.pointedType = pointedType;
//    }

    public ValueType getPointedType() {
        return this.pointedType;
    }

    @Override
    public int getBytes() {
        return 4;
    }

    @Override
    public int getBits() {
        return 32;
    }

    @Override
    public String toString() {
        return pointedType.toString() + "*";
    }
}
